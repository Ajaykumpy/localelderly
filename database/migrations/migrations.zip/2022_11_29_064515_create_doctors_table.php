<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDoctorsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::dropIfExists('doctors');
        Schema::create('doctors', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('name');
            $table->bigInteger('mobile');
            $table->string('email')->unique('users_email_unique');
            $table->timestamp('email_verified_at')->nullable();
            $table->string('pin');
            $table->rememberToken();
            $table->string('gender', 15);
            $table->string('state', 100);
            $table->string('city', 100);
            $table->bigInteger('registration_number');
            $table->string('registration_council', 100);
            $table->string('registration_year', 10);
            $table->string('degree');
            $table->string('college_institute');
            $table->integer('yrs_of_exp');
            $table->integer('yrs_of_completion');
            $table->integer('specialist');
            $table->string('icon')->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('doctors');
    }
}
