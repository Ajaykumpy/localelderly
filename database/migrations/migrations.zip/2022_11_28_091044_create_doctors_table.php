<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('doctors', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name', 100);
            $table->integer('mobile');
            $table->string('email', 100)->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->integer('pin');
            $table->integer('specialist_id');
            $table->string('gender', 10);
            $table->string('state', 100);
            $table->string('city', 100);
            $table->integer('registration_number');
            $table->integer('registration_council');
            $table->integer('registration_year');
            $table->string('degree', 100);
            $table->string('college_institute', 100);
            $table->string('yrs_of_exp');
            $table->string('yrs_of_completion');
            $table->string('remember_token', 255);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('doctors');
    }
};
